'''
    TODO: I want to make this an file just to get and output the results in the terminal
'''